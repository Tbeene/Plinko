gdjs.GameSceneCode = {};
gdjs.GameSceneCode.forEachCount0_2 = 0;

gdjs.GameSceneCode.forEachCount1_2 = 0;

gdjs.GameSceneCode.forEachIndex2 = 0;

gdjs.GameSceneCode.forEachObjects2 = [];

gdjs.GameSceneCode.forEachTotalCount2 = 0;

gdjs.GameSceneCode.GDPeg_9595BasicObjects1= [];
gdjs.GameSceneCode.GDPeg_9595BasicObjects2= [];
gdjs.GameSceneCode.GDPeg_9595BasicObjects3= [];
gdjs.GameSceneCode.GDPeg_9595BasicObjects4= [];
gdjs.GameSceneCode.GDPeg_9595MoveObjects1= [];
gdjs.GameSceneCode.GDPeg_9595MoveObjects2= [];
gdjs.GameSceneCode.GDPeg_9595MoveObjects3= [];
gdjs.GameSceneCode.GDPeg_9595MoveObjects4= [];
gdjs.GameSceneCode.GDPeg_9595BiggerObjects1= [];
gdjs.GameSceneCode.GDPeg_9595BiggerObjects2= [];
gdjs.GameSceneCode.GDPeg_9595BiggerObjects3= [];
gdjs.GameSceneCode.GDPeg_9595BiggerObjects4= [];
gdjs.GameSceneCode.GDMultiplierObjects1= [];
gdjs.GameSceneCode.GDMultiplierObjects2= [];
gdjs.GameSceneCode.GDMultiplierObjects3= [];
gdjs.GameSceneCode.GDMultiplierObjects4= [];
gdjs.GameSceneCode.GDBallObjects1= [];
gdjs.GameSceneCode.GDBallObjects2= [];
gdjs.GameSceneCode.GDBallObjects3= [];
gdjs.GameSceneCode.GDBallObjects4= [];
gdjs.GameSceneCode.GDScoreObjects1= [];
gdjs.GameSceneCode.GDScoreObjects2= [];
gdjs.GameSceneCode.GDScoreObjects3= [];
gdjs.GameSceneCode.GDScoreObjects4= [];
gdjs.GameSceneCode.GDScoreMultiplierObjects1= [];
gdjs.GameSceneCode.GDScoreMultiplierObjects2= [];
gdjs.GameSceneCode.GDScoreMultiplierObjects3= [];
gdjs.GameSceneCode.GDScoreMultiplierObjects4= [];
gdjs.GameSceneCode.GDLivesObjects1= [];
gdjs.GameSceneCode.GDLivesObjects2= [];
gdjs.GameSceneCode.GDLivesObjects3= [];
gdjs.GameSceneCode.GDLivesObjects4= [];
gdjs.GameSceneCode.GDWallsObjects1= [];
gdjs.GameSceneCode.GDWallsObjects2= [];
gdjs.GameSceneCode.GDWallsObjects3= [];
gdjs.GameSceneCode.GDWallsObjects4= [];
gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects1= [];
gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects2= [];
gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects3= [];
gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects4= [];
gdjs.GameSceneCode.GDPegBig_9595ParticleObjects1= [];
gdjs.GameSceneCode.GDPegBig_9595ParticleObjects2= [];
gdjs.GameSceneCode.GDPegBig_9595ParticleObjects3= [];
gdjs.GameSceneCode.GDPegBig_9595ParticleObjects4= [];
gdjs.GameSceneCode.GDPegStar_9595ParticleObjects1= [];
gdjs.GameSceneCode.GDPegStar_9595ParticleObjects2= [];
gdjs.GameSceneCode.GDPegStar_9595ParticleObjects3= [];
gdjs.GameSceneCode.GDPegStar_9595ParticleObjects4= [];
gdjs.GameSceneCode.GDDarkeningObjects1= [];
gdjs.GameSceneCode.GDDarkeningObjects2= [];
gdjs.GameSceneCode.GDDarkeningObjects3= [];
gdjs.GameSceneCode.GDDarkeningObjects4= [];
gdjs.GameSceneCode.GDGameOverObjects1= [];
gdjs.GameSceneCode.GDGameOverObjects2= [];
gdjs.GameSceneCode.GDGameOverObjects3= [];
gdjs.GameSceneCode.GDGameOverObjects4= [];
gdjs.GameSceneCode.GDUI_9595BlockObjects1= [];
gdjs.GameSceneCode.GDUI_9595BlockObjects2= [];
gdjs.GameSceneCode.GDUI_9595BlockObjects3= [];
gdjs.GameSceneCode.GDUI_9595BlockObjects4= [];
gdjs.GameSceneCode.GDNewTextInputObjects1= [];
gdjs.GameSceneCode.GDNewTextInputObjects2= [];
gdjs.GameSceneCode.GDNewTextInputObjects3= [];
gdjs.GameSceneCode.GDNewTextInputObjects4= [];
gdjs.GameSceneCode.GDSubmitScoreObjects1= [];
gdjs.GameSceneCode.GDSubmitScoreObjects2= [];
gdjs.GameSceneCode.GDSubmitScoreObjects3= [];
gdjs.GameSceneCode.GDSubmitScoreObjects4= [];
gdjs.GameSceneCode.GDRestartGameObjects1= [];
gdjs.GameSceneCode.GDRestartGameObjects2= [];
gdjs.GameSceneCode.GDRestartGameObjects3= [];
gdjs.GameSceneCode.GDRestartGameObjects4= [];
gdjs.GameSceneCode.GDCloudLayer3Objects1= [];
gdjs.GameSceneCode.GDCloudLayer3Objects2= [];
gdjs.GameSceneCode.GDCloudLayer3Objects3= [];
gdjs.GameSceneCode.GDCloudLayer3Objects4= [];
gdjs.GameSceneCode.GDBackgroundObjects1= [];
gdjs.GameSceneCode.GDBackgroundObjects2= [];
gdjs.GameSceneCode.GDBackgroundObjects3= [];
gdjs.GameSceneCode.GDBackgroundObjects4= [];
gdjs.GameSceneCode.GDBlackOrbObjects1= [];
gdjs.GameSceneCode.GDBlackOrbObjects2= [];
gdjs.GameSceneCode.GDBlackOrbObjects3= [];
gdjs.GameSceneCode.GDBlackOrbObjects4= [];
gdjs.GameSceneCode.GDMoving_9595PepperObjects1= [];
gdjs.GameSceneCode.GDMoving_9595PepperObjects2= [];
gdjs.GameSceneCode.GDMoving_9595PepperObjects3= [];
gdjs.GameSceneCode.GDMoving_9595PepperObjects4= [];
gdjs.GameSceneCode.GDNewTextObjects1= [];
gdjs.GameSceneCode.GDNewTextObjects2= [];
gdjs.GameSceneCode.GDNewTextObjects3= [];
gdjs.GameSceneCode.GDNewTextObjects4= [];
gdjs.GameSceneCode.GDNewSpriteObjects1= [];
gdjs.GameSceneCode.GDNewSpriteObjects2= [];
gdjs.GameSceneCode.GDNewSpriteObjects3= [];
gdjs.GameSceneCode.GDNewSpriteObjects4= [];
gdjs.GameSceneCode.GDNewText2Objects1= [];
gdjs.GameSceneCode.GDNewText2Objects2= [];
gdjs.GameSceneCode.GDNewText2Objects3= [];
gdjs.GameSceneCode.GDNewText2Objects4= [];
gdjs.GameSceneCode.GDNewSprite2Objects1= [];
gdjs.GameSceneCode.GDNewSprite2Objects2= [];
gdjs.GameSceneCode.GDNewSprite2Objects3= [];
gdjs.GameSceneCode.GDNewSprite2Objects4= [];


gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBallObjects2Objects = Hashtable.newFrom({"Ball": gdjs.GameSceneCode.GDBallObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPeg_95959595BasicObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDPeg_95959595MoveObjects2Objects = Hashtable.newFrom({"Peg_Basic": gdjs.GameSceneCode.GDPeg_9595BasicObjects2, "Peg_Move": gdjs.GameSceneCode.GDPeg_9595MoveObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPegDeath_95959595ParticleObjects3Objects = Hashtable.newFrom({"PegDeath_Particle": gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects3});
gdjs.GameSceneCode.eventsList0 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDPeg_9595BasicObjects2, gdjs.GameSceneCode.GDPeg_9595BasicObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDPeg_9595MoveObjects2, gdjs.GameSceneCode.GDPeg_9595MoveObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPeg_9595BasicObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPeg_9595BasicObjects3[i].getOpacity() < 180 ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPeg_9595BasicObjects3[k] = gdjs.GameSceneCode.GDPeg_9595BasicObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPeg_9595BasicObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPeg_9595MoveObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPeg_9595MoveObjects3[i].getOpacity() < 180 ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPeg_9595MoveObjects3[k] = gdjs.GameSceneCode.GDPeg_9595MoveObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPeg_9595MoveObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPeg_9595BasicObjects3 */
/* Reuse gdjs.GameSceneCode.GDPeg_9595MoveObjects3 */
gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects3.length = 0;

{for(var i = 0, len = gdjs.GameSceneCode.GDPeg_9595BasicObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPeg_9595BasicObjects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDPeg_9595MoveObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPeg_9595MoveObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPegDeath_95959595ParticleObjects3Objects, (( gdjs.GameSceneCode.GDPeg_9595MoveObjects3.length === 0 ) ? (( gdjs.GameSceneCode.GDPeg_9595BasicObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPeg_9595BasicObjects3[0].getPointX("")) :gdjs.GameSceneCode.GDPeg_9595MoveObjects3[0].getPointX("")), (( gdjs.GameSceneCode.GDPeg_9595MoveObjects3.length === 0 ) ? (( gdjs.GameSceneCode.GDPeg_9595BasicObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPeg_9595BasicObjects3[0].getPointY("")) :gdjs.GameSceneCode.GDPeg_9595MoveObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects3[i].setZOrder(0);
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.GameSceneCode.GDBallObjects1});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPeg_95959595BiggerObjects1Objects = Hashtable.newFrom({"Peg_Bigger": gdjs.GameSceneCode.GDPeg_9595BiggerObjects1});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPegBig_95959595ParticleObjects1Objects = Hashtable.newFrom({"PegBig_Particle": gdjs.GameSceneCode.GDPegBig_9595ParticleObjects1});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.GameSceneCode.GDBallObjects1});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDMultiplierObjects1Objects = Hashtable.newFrom({"Multiplier": gdjs.GameSceneCode.GDMultiplierObjects1});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPegStar_95959595ParticleObjects1Objects = Hashtable.newFrom({"PegStar_Particle": gdjs.GameSceneCode.GDPegStar_9595ParticleObjects1});
gdjs.GameSceneCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1.25;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDScoreMultiplierObjects1, gdjs.GameSceneCode.GDScoreMultiplierObjects2);

{for(var i = 0, len = gdjs.GameSceneCode.GDScoreMultiplierObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDScoreMultiplierObjects2[i].setString("+25%");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1.50;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDScoreMultiplierObjects1, gdjs.GameSceneCode.GDScoreMultiplierObjects2);

{for(var i = 0, len = gdjs.GameSceneCode.GDScoreMultiplierObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDScoreMultiplierObjects2[i].setString("+50%");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1.75;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDScoreMultiplierObjects1, gdjs.GameSceneCode.GDScoreMultiplierObjects2);

{for(var i = 0, len = gdjs.GameSceneCode.GDScoreMultiplierObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDScoreMultiplierObjects2[i].setString("+75%");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDScoreMultiplierObjects1 */
{for(var i = 0, len = gdjs.GameSceneCode.GDScoreMultiplierObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDScoreMultiplierObjects1[i].setString("+100%");
}
}}

}


};gdjs.GameSceneCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDBallObjects1, gdjs.GameSceneCode.GDBallObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDBallObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDBallObjects2[i].getVariableNumber(gdjs.GameSceneCode.GDBallObjects2[i].getVariables().getFromIndex(2)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDBallObjects2[k] = gdjs.GameSceneCode.GDBallObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDBallObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "BallRespawn.wav", false, 45, 1.2);
}}

}


{

/* Reuse gdjs.GameSceneCode.GDBallObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDBallObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDBallObjects1[i].getVariableNumber(gdjs.GameSceneCode.GDBallObjects1[i].getVariables().getFromIndex(2)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDBallObjects1[k] = gdjs.GameSceneCode.GDBallObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDBallObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDBallObjects1 */
{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "GameOver");
}}

}


};gdjs.GameSceneCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11498188);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDBallObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Lives"), gdjs.GameSceneCode.GDLivesObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].setVariableBoolean(gdjs.GameSceneCode.GDBallObjects1[i].getVariables().getFromIndex(1), true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].activateBehavior("Physics2", true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ClickerBeep.wav", false, 50, 0.8);
}{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].returnVariable(gdjs.GameSceneCode.GDBallObjects1[i].getVariables().getFromIndex(2)).sub(1);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDLivesObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDLivesObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(1, 0, -(10), 0, 0.2, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDSubmitScoreObjects2Objects = Hashtable.newFrom({"SubmitScore": gdjs.GameSceneCode.GDSubmitScoreObjects2});
gdjs.GameSceneCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11505972);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDSubmitScoreObjects2, gdjs.GameSceneCode.GDSubmitScoreObjects3);

{for(var i = 0, len = gdjs.GameSceneCode.GDSubmitScoreObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDSubmitScoreObjects3[i].setColor("255;235;0");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11507060);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewTextInput"), gdjs.GameSceneCode.GDNewTextInputObjects2);
{gdjs.evtTools.leaderboards.savePlayerScore(runtimeScene, "2a0fb72c-383e-40e8-86b9-09e95e13de51", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)), (( gdjs.GameSceneCode.GDNewTextInputObjects2.length === 0 ) ? "" :gdjs.GameSceneCode.GDNewTextInputObjects2[0].getText()));
}{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "2a0fb72c-383e-40e8-86b9-09e95e13de51", true);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDSubmitScoreObjects2Objects = Hashtable.newFrom({"SubmitScore": gdjs.GameSceneCode.GDSubmitScoreObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDRestartGameObjects2Objects = Hashtable.newFrom({"RestartGame": gdjs.GameSceneCode.GDRestartGameObjects2});
gdjs.GameSceneCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11511652);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDRestartGameObjects2, gdjs.GameSceneCode.GDRestartGameObjects3);

{for(var i = 0, len = gdjs.GameSceneCode.GDRestartGameObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDRestartGameObjects3[i].setColor("255;235;0");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11512740);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameScene", false);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDRestartGameObjects2Objects = Hashtable.newFrom({"RestartGame": gdjs.GameSceneCode.GDRestartGameObjects2});
gdjs.GameSceneCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11503428);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Darkening"), gdjs.GameSceneCode.GDDarkeningObjects2);
gdjs.copyArray(runtimeScene.getObjects("GameOver"), gdjs.GameSceneCode.GDGameOverObjects2);
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameSceneCode.GDScoreObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "so-were-in-copper.mp3", false, 40, 1);
}{for(var i = 0, len = gdjs.GameSceneCode.GDGameOverObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDGameOverObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(4, 0, 70, 0, 2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDDarkeningObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDDarkeningObjects2[i].setOpacity(220);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDScoreObjects2[i].setLayer("Score");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SubmitScore"), gdjs.GameSceneCode.GDSubmitScoreObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDSubmitScoreObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SubmitScore"), gdjs.GameSceneCode.GDSubmitScoreObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDSubmitScoreObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDSubmitScoreObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDSubmitScoreObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDSubmitScoreObjects2[i].setColor("255;255;255");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RestartGame"), gdjs.GameSceneCode.GDRestartGameObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDRestartGameObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("RestartGame"), gdjs.GameSceneCode.GDRestartGameObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDRestartGameObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDRestartGameObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDRestartGameObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDRestartGameObjects2[i].setColor("255;255;255");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.leaderboards.isLeaderboardViewLoaded();
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Leaderboard", false);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBallObjects2Objects = Hashtable.newFrom({"Ball": gdjs.GameSceneCode.GDBallObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDMoving_95959595PepperObjects2Objects = Hashtable.newFrom({"Moving_Pepper": gdjs.GameSceneCode.GDMoving_9595PepperObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPegDeath_95959595ParticleObjects3Objects = Hashtable.newFrom({"PegDeath_Particle": gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects3});
gdjs.GameSceneCode.eventsList7 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDMoving_9595PepperObjects2, gdjs.GameSceneCode.GDMoving_9595PepperObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDMoving_9595PepperObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDMoving_9595PepperObjects3[i].getOpacity() < 180 ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDMoving_9595PepperObjects3[k] = gdjs.GameSceneCode.GDMoving_9595PepperObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDMoving_9595PepperObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDMoving_9595PepperObjects3 */
gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects3.length = 0;

{for(var i = 0, len = gdjs.GameSceneCode.GDMoving_9595PepperObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDMoving_9595PepperObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPegDeath_95959595ParticleObjects3Objects, (( gdjs.GameSceneCode.GDMoving_9595PepperObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDMoving_9595PepperObjects3[0].getPointX("")), (( gdjs.GameSceneCode.GDMoving_9595PepperObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDMoving_9595PepperObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects3[i].setZOrder(0);
}
}}

}


};gdjs.GameSceneCode.eventsList8 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.GameSceneCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameSceneCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("CloudLayer3"), gdjs.GameSceneCode.GDCloudLayer3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Multiplier"), gdjs.GameSceneCode.GDMultiplierObjects1);
gdjs.copyArray(runtimeScene.getObjects("ScoreMultiplier"), gdjs.GameSceneCode.GDScoreMultiplierObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDMultiplierObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDMultiplierObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(2, 0, 10, 30, 0, 2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDScoreMultiplierObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDScoreMultiplierObjects1[i].setString("");
}
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.GameSceneCode.GDBackgroundObjects1.length !== 0 ? gdjs.GameSceneCode.GDBackgroundObjects1[0] : null), true, "Background", 0);
}{for(var i = 0, len = gdjs.GameSceneCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBackgroundObjects1[i].setColor("233;178;178");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBackgroundObjects1[i].setXOffset(gdjs.GameSceneCode.GDBackgroundObjects1[i].getXOffset() - (100));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDCloudLayer3Objects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCloudLayer3Objects1[i].setOpacity(100);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDCloudLayer3Objects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCloudLayer3Objects1[i].setColor("143;98;168");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].activateBehavior("Physics2", false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Peg_Basic"), gdjs.GameSceneCode.GDPeg_9595BasicObjects1);
gdjs.copyArray(runtimeScene.getObjects("Peg_Move"), gdjs.GameSceneCode.GDPeg_9595MoveObjects1);

gdjs.GameSceneCode.forEachTotalCount2 = 0;
gdjs.GameSceneCode.forEachObjects2.length = 0;
gdjs.GameSceneCode.forEachCount0_2 = gdjs.GameSceneCode.GDPeg_9595BasicObjects1.length;
gdjs.GameSceneCode.forEachTotalCount2 += gdjs.GameSceneCode.forEachCount0_2;
gdjs.GameSceneCode.forEachObjects2.push.apply(gdjs.GameSceneCode.forEachObjects2,gdjs.GameSceneCode.GDPeg_9595BasicObjects1);
gdjs.GameSceneCode.forEachCount1_2 = gdjs.GameSceneCode.GDPeg_9595MoveObjects1.length;
gdjs.GameSceneCode.forEachTotalCount2 += gdjs.GameSceneCode.forEachCount1_2;
gdjs.GameSceneCode.forEachObjects2.push.apply(gdjs.GameSceneCode.forEachObjects2,gdjs.GameSceneCode.GDPeg_9595MoveObjects1);
for (gdjs.GameSceneCode.forEachIndex2 = 0;gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachTotalCount2;++gdjs.GameSceneCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameSceneCode.GDBallObjects2);
gdjs.GameSceneCode.GDPeg_9595BasicObjects2.length = 0;

gdjs.GameSceneCode.GDPeg_9595MoveObjects2.length = 0;


if (gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachCount0_2) {
    gdjs.GameSceneCode.GDPeg_9595BasicObjects2.push(gdjs.GameSceneCode.forEachObjects2[gdjs.GameSceneCode.forEachIndex2]);
}
else if (gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachCount0_2+gdjs.GameSceneCode.forEachCount1_2) {
    gdjs.GameSceneCode.GDPeg_9595MoveObjects2.push(gdjs.GameSceneCode.forEachObjects2[gdjs.GameSceneCode.forEachIndex2]);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.haveObjectsStartedColliding(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBallObjects2Objects, "Physics2", gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPeg_95959595BasicObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDPeg_95959595MoveObjects2Objects, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{gdjs.evtTools.sound.playSound(runtimeScene, "sizzle-104894.mp3", false, 10, (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDBallObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDBallObjects2[0].getVariables()).getFromIndex(0))));
}{for(var i = 0, len = gdjs.GameSceneCode.GDPeg_9595BasicObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPeg_9595BasicObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 0, 0, 0, -(30), 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.GameSceneCode.GDPeg_9595MoveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPeg_9595MoveObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 0, 0, 0, -(30), 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDPeg_9595BasicObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPeg_9595BasicObjects2[i].setOpacity(gdjs.GameSceneCode.GDPeg_9595BasicObjects2[i].getOpacity() - (30));
}
for(var i = 0, len = gdjs.GameSceneCode.GDPeg_9595MoveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPeg_9595MoveObjects2[i].setOpacity(gdjs.GameSceneCode.GDPeg_9595MoveObjects2[i].getOpacity() - (30));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects2[i].returnVariable(gdjs.GameSceneCode.GDBallObjects2[i].getVariables().getFromIndex(0)).add(0.05);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Ball_Pitch");
}{for(var i = 0, len = gdjs.GameSceneCode.GDPeg_9595BasicObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPeg_9595BasicObjects2[i].setColor("114;114;114");
}
for(var i = 0, len = gdjs.GameSceneCode.GDPeg_9595MoveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPeg_9595MoveObjects2[i].setColor("114;114;114");
}
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList0(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameSceneCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("Peg_Bigger"), gdjs.GameSceneCode.GDPeg_9595BiggerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.haveObjectsStartedColliding(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBallObjects1Objects, "Physics2", gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPeg_95959595BiggerObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDBallObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PegDeath_Particle"), gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects1);
/* Reuse gdjs.GameSceneCode.GDPeg_9595BiggerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameSceneCode.GDScoreObjects1);
gdjs.GameSceneCode.GDPegBig_9595ParticleObjects1.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(0).add(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) * 2);
}{gdjs.evtTools.sound.playSound(runtimeScene, "ClickerBeep.wav", false, 30, 0.8);
}{for(var i = 0, len = gdjs.GameSceneCode.GDPeg_9595BiggerObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPeg_9595BiggerObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.3, 0, 0, 0, 20, 0.15, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].returnVariable(gdjs.GameSceneCode.GDBallObjects1[i].getVariables().getFromIndex(0)).add(0.05);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Ball_Pitch");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPegBig_95959595ParticleObjects1Objects, (( gdjs.GameSceneCode.GDPeg_9595BiggerObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPeg_9595BiggerObjects1[0].getPointX("")), (( gdjs.GameSceneCode.GDPeg_9595BiggerObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPeg_9595BiggerObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects1[i].setZOrder(0);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDScoreObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(1, 0, -(10), 0, 0.2, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameSceneCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("Multiplier"), gdjs.GameSceneCode.GDMultiplierObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBallObjects1Objects, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDMultiplierObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11486012);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDMultiplierObjects1 */
gdjs.copyArray(runtimeScene.getObjects("ScoreMultiplier"), gdjs.GameSceneCode.GDScoreMultiplierObjects1);
gdjs.GameSceneCode.GDPegStar_9595ParticleObjects1.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "ClickerBeep2.wav", false, 35, 0.8);
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(0.25);
}{for(var i = 0, len = gdjs.GameSceneCode.GDMultiplierObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDMultiplierObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPegStar_95959595ParticleObjects1Objects, (( gdjs.GameSceneCode.GDMultiplierObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDMultiplierObjects1[0].getPointX("")), (( gdjs.GameSceneCode.GDMultiplierObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDMultiplierObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDScoreMultiplierObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDScoreMultiplierObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 8, 8, 0, 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Ball_Pitch") > 0.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11493316);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameSceneCode.GDBallObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].returnVariable(gdjs.GameSceneCode.GDBallObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameSceneCode.GDBallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDBallObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDBallObjects1[i].getY() > 1000 ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDBallObjects1[k] = gdjs.GameSceneCode.GDBallObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDBallObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDBallObjects1 */
{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].activateBehavior("Physics2", false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].setY(120);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].setVariableBoolean(gdjs.GameSceneCode.GDBallObjects1[i].getVariables().getFromIndex(1), false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.4, 0, 0, 0, 60, 0.4, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameSceneCode.GDBallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDBallObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDBallObjects1[i].getVariableBoolean(gdjs.GameSceneCode.GDBallObjects1[i].getVariables().getFromIndex(1), false) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDBallObjects1[k] = gdjs.GameSceneCode.GDBallObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDBallObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDBallObjects1 */
{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects1[i].setX(gdjs.evtTools.common.clamp(48, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), 752));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameSceneCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("Lives"), gdjs.GameSceneCode.GDLivesObjects1);
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameSceneCode.GDScoreObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}{for(var i = 0, len = gdjs.GameSceneCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDScoreObjects1[i].setString("Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDLivesObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDLivesObjects1[i].setString("Lives: " + (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDBallObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDBallObjects1[0].getVariables()).getFromIndex(2))));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "GameOver");
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CloudLayer3"), gdjs.GameSceneCode.GDCloudLayer3Objects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDCloudLayer3Objects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCloudLayer3Objects1[i].returnVariable(gdjs.GameSceneCode.GDCloudLayer3Objects1[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomFloatInRange(3, 7));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CloudLayer3"), gdjs.GameSceneCode.GDCloudLayer3Objects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDCloudLayer3Objects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCloudLayer3Objects1[i].setXOffset(gdjs.GameSceneCode.GDCloudLayer3Objects1[i].getXOffset() + ((gdjs.RuntimeObject.getVariableNumber(gdjs.GameSceneCode.GDCloudLayer3Objects1[i].getVariables().getFromIndex(0))) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Peg_Basic"), gdjs.GameSceneCode.GDPeg_9595BasicObjects1);
gdjs.copyArray(runtimeScene.getObjects("Peg_Move"), gdjs.GameSceneCode.GDPeg_9595MoveObjects1);

gdjs.GameSceneCode.forEachTotalCount2 = 0;
gdjs.GameSceneCode.forEachObjects2.length = 0;
gdjs.GameSceneCode.forEachCount0_2 = gdjs.GameSceneCode.GDPeg_9595BasicObjects1.length;
gdjs.GameSceneCode.forEachTotalCount2 += gdjs.GameSceneCode.forEachCount0_2;
gdjs.GameSceneCode.forEachObjects2.push.apply(gdjs.GameSceneCode.forEachObjects2,gdjs.GameSceneCode.GDPeg_9595BasicObjects1);
gdjs.GameSceneCode.forEachCount1_2 = gdjs.GameSceneCode.GDPeg_9595MoveObjects1.length;
gdjs.GameSceneCode.forEachTotalCount2 += gdjs.GameSceneCode.forEachCount1_2;
gdjs.GameSceneCode.forEachObjects2.push.apply(gdjs.GameSceneCode.forEachObjects2,gdjs.GameSceneCode.GDPeg_9595MoveObjects1);
for (gdjs.GameSceneCode.forEachIndex2 = 0;gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachTotalCount2;++gdjs.GameSceneCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameSceneCode.GDBallObjects2);
gdjs.copyArray(runtimeScene.getObjects("Moving_Pepper"), gdjs.GameSceneCode.GDMoving_9595PepperObjects2);
gdjs.GameSceneCode.GDPeg_9595BasicObjects2.length = 0;

gdjs.GameSceneCode.GDPeg_9595MoveObjects2.length = 0;


if (gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachCount0_2) {
    gdjs.GameSceneCode.GDPeg_9595BasicObjects2.push(gdjs.GameSceneCode.forEachObjects2[gdjs.GameSceneCode.forEachIndex2]);
}
else if (gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.forEachCount0_2+gdjs.GameSceneCode.forEachCount1_2) {
    gdjs.GameSceneCode.GDPeg_9595MoveObjects2.push(gdjs.GameSceneCode.forEachObjects2[gdjs.GameSceneCode.forEachIndex2]);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.haveObjectsStartedColliding(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDBallObjects2Objects, "Physics2", gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDMoving_95959595PepperObjects2Objects, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(10);
}{gdjs.evtTools.sound.playSound(runtimeScene, "grunt1-84540.mp3", false, 20, (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDBallObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDBallObjects2[0].getVariables()).getFromIndex(0))));
}{for(var i = 0, len = gdjs.GameSceneCode.GDPeg_9595BasicObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPeg_9595BasicObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 0, 0, 0, -(30), 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.GameSceneCode.GDPeg_9595MoveObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPeg_9595MoveObjects2[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.2, 0, 0, 0, -(30), 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDMoving_9595PepperObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDMoving_9595PepperObjects2[i].setOpacity(gdjs.GameSceneCode.GDMoving_9595PepperObjects2[i].getOpacity() - (180));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBallObjects2[i].returnVariable(gdjs.GameSceneCode.GDBallObjects2[i].getVariables().getFromIndex(0)).add(0.05);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Ball_Pitch");
}{for(var i = 0, len = gdjs.GameSceneCode.GDMoving_9595PepperObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDMoving_9595PepperObjects2[i].setColor("114;114;114");
}
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList7(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.GameSceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.GameSceneCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText2"), gdjs.GameSceneCode.GDNewText2Objects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDNewSpriteObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDNewTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDNewText2Objects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDNewText2Objects1[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.GameSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameSceneCode.GDPeg_9595BasicObjects1.length = 0;
gdjs.GameSceneCode.GDPeg_9595BasicObjects2.length = 0;
gdjs.GameSceneCode.GDPeg_9595BasicObjects3.length = 0;
gdjs.GameSceneCode.GDPeg_9595BasicObjects4.length = 0;
gdjs.GameSceneCode.GDPeg_9595MoveObjects1.length = 0;
gdjs.GameSceneCode.GDPeg_9595MoveObjects2.length = 0;
gdjs.GameSceneCode.GDPeg_9595MoveObjects3.length = 0;
gdjs.GameSceneCode.GDPeg_9595MoveObjects4.length = 0;
gdjs.GameSceneCode.GDPeg_9595BiggerObjects1.length = 0;
gdjs.GameSceneCode.GDPeg_9595BiggerObjects2.length = 0;
gdjs.GameSceneCode.GDPeg_9595BiggerObjects3.length = 0;
gdjs.GameSceneCode.GDPeg_9595BiggerObjects4.length = 0;
gdjs.GameSceneCode.GDMultiplierObjects1.length = 0;
gdjs.GameSceneCode.GDMultiplierObjects2.length = 0;
gdjs.GameSceneCode.GDMultiplierObjects3.length = 0;
gdjs.GameSceneCode.GDMultiplierObjects4.length = 0;
gdjs.GameSceneCode.GDBallObjects1.length = 0;
gdjs.GameSceneCode.GDBallObjects2.length = 0;
gdjs.GameSceneCode.GDBallObjects3.length = 0;
gdjs.GameSceneCode.GDBallObjects4.length = 0;
gdjs.GameSceneCode.GDScoreObjects1.length = 0;
gdjs.GameSceneCode.GDScoreObjects2.length = 0;
gdjs.GameSceneCode.GDScoreObjects3.length = 0;
gdjs.GameSceneCode.GDScoreObjects4.length = 0;
gdjs.GameSceneCode.GDScoreMultiplierObjects1.length = 0;
gdjs.GameSceneCode.GDScoreMultiplierObjects2.length = 0;
gdjs.GameSceneCode.GDScoreMultiplierObjects3.length = 0;
gdjs.GameSceneCode.GDScoreMultiplierObjects4.length = 0;
gdjs.GameSceneCode.GDLivesObjects1.length = 0;
gdjs.GameSceneCode.GDLivesObjects2.length = 0;
gdjs.GameSceneCode.GDLivesObjects3.length = 0;
gdjs.GameSceneCode.GDLivesObjects4.length = 0;
gdjs.GameSceneCode.GDWallsObjects1.length = 0;
gdjs.GameSceneCode.GDWallsObjects2.length = 0;
gdjs.GameSceneCode.GDWallsObjects3.length = 0;
gdjs.GameSceneCode.GDWallsObjects4.length = 0;
gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects1.length = 0;
gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects2.length = 0;
gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects3.length = 0;
gdjs.GameSceneCode.GDPegDeath_9595ParticleObjects4.length = 0;
gdjs.GameSceneCode.GDPegBig_9595ParticleObjects1.length = 0;
gdjs.GameSceneCode.GDPegBig_9595ParticleObjects2.length = 0;
gdjs.GameSceneCode.GDPegBig_9595ParticleObjects3.length = 0;
gdjs.GameSceneCode.GDPegBig_9595ParticleObjects4.length = 0;
gdjs.GameSceneCode.GDPegStar_9595ParticleObjects1.length = 0;
gdjs.GameSceneCode.GDPegStar_9595ParticleObjects2.length = 0;
gdjs.GameSceneCode.GDPegStar_9595ParticleObjects3.length = 0;
gdjs.GameSceneCode.GDPegStar_9595ParticleObjects4.length = 0;
gdjs.GameSceneCode.GDDarkeningObjects1.length = 0;
gdjs.GameSceneCode.GDDarkeningObjects2.length = 0;
gdjs.GameSceneCode.GDDarkeningObjects3.length = 0;
gdjs.GameSceneCode.GDDarkeningObjects4.length = 0;
gdjs.GameSceneCode.GDGameOverObjects1.length = 0;
gdjs.GameSceneCode.GDGameOverObjects2.length = 0;
gdjs.GameSceneCode.GDGameOverObjects3.length = 0;
gdjs.GameSceneCode.GDGameOverObjects4.length = 0;
gdjs.GameSceneCode.GDUI_9595BlockObjects1.length = 0;
gdjs.GameSceneCode.GDUI_9595BlockObjects2.length = 0;
gdjs.GameSceneCode.GDUI_9595BlockObjects3.length = 0;
gdjs.GameSceneCode.GDUI_9595BlockObjects4.length = 0;
gdjs.GameSceneCode.GDNewTextInputObjects1.length = 0;
gdjs.GameSceneCode.GDNewTextInputObjects2.length = 0;
gdjs.GameSceneCode.GDNewTextInputObjects3.length = 0;
gdjs.GameSceneCode.GDNewTextInputObjects4.length = 0;
gdjs.GameSceneCode.GDSubmitScoreObjects1.length = 0;
gdjs.GameSceneCode.GDSubmitScoreObjects2.length = 0;
gdjs.GameSceneCode.GDSubmitScoreObjects3.length = 0;
gdjs.GameSceneCode.GDSubmitScoreObjects4.length = 0;
gdjs.GameSceneCode.GDRestartGameObjects1.length = 0;
gdjs.GameSceneCode.GDRestartGameObjects2.length = 0;
gdjs.GameSceneCode.GDRestartGameObjects3.length = 0;
gdjs.GameSceneCode.GDRestartGameObjects4.length = 0;
gdjs.GameSceneCode.GDCloudLayer3Objects1.length = 0;
gdjs.GameSceneCode.GDCloudLayer3Objects2.length = 0;
gdjs.GameSceneCode.GDCloudLayer3Objects3.length = 0;
gdjs.GameSceneCode.GDCloudLayer3Objects4.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects1.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects2.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects3.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects4.length = 0;
gdjs.GameSceneCode.GDBlackOrbObjects1.length = 0;
gdjs.GameSceneCode.GDBlackOrbObjects2.length = 0;
gdjs.GameSceneCode.GDBlackOrbObjects3.length = 0;
gdjs.GameSceneCode.GDBlackOrbObjects4.length = 0;
gdjs.GameSceneCode.GDMoving_9595PepperObjects1.length = 0;
gdjs.GameSceneCode.GDMoving_9595PepperObjects2.length = 0;
gdjs.GameSceneCode.GDMoving_9595PepperObjects3.length = 0;
gdjs.GameSceneCode.GDMoving_9595PepperObjects4.length = 0;
gdjs.GameSceneCode.GDNewTextObjects1.length = 0;
gdjs.GameSceneCode.GDNewTextObjects2.length = 0;
gdjs.GameSceneCode.GDNewTextObjects3.length = 0;
gdjs.GameSceneCode.GDNewTextObjects4.length = 0;
gdjs.GameSceneCode.GDNewSpriteObjects1.length = 0;
gdjs.GameSceneCode.GDNewSpriteObjects2.length = 0;
gdjs.GameSceneCode.GDNewSpriteObjects3.length = 0;
gdjs.GameSceneCode.GDNewSpriteObjects4.length = 0;
gdjs.GameSceneCode.GDNewText2Objects1.length = 0;
gdjs.GameSceneCode.GDNewText2Objects2.length = 0;
gdjs.GameSceneCode.GDNewText2Objects3.length = 0;
gdjs.GameSceneCode.GDNewText2Objects4.length = 0;
gdjs.GameSceneCode.GDNewSprite2Objects1.length = 0;
gdjs.GameSceneCode.GDNewSprite2Objects2.length = 0;
gdjs.GameSceneCode.GDNewSprite2Objects3.length = 0;
gdjs.GameSceneCode.GDNewSprite2Objects4.length = 0;

gdjs.GameSceneCode.eventsList8(runtimeScene);

return;

}

gdjs['GameSceneCode'] = gdjs.GameSceneCode;
